require('dotenv').config(); 

// services/lineService.js
const Line = require('../models/lines');

class LineService {
    async createLine(data) {
        return await Line.create(data);
    }

    async getAllLines() {
        return await Line.findAll();
    }

    async getLineById(id) {
        return await Line.findByPk(id);
    }

    async updateLine(id, data) {
        const line = await Line.findByPk(id);
        if (line) {
            return await line.update(data);
        }
        throw new Error('Line not found');
    }

    async deleteLine(id) {
        const line = await Line.findByPk(id);
        if (line) {
            return await line.destroy();
        }
        throw new Error('Line not found');
    }
}

module.exports = LineService;
