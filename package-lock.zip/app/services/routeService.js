require('dotenv').config(); 

// services/routeService.js
const Route = require('../models/routesModel');
const Line = require('../models/lines');
const Path = require('../models/paths');

class RouteService {
    async createRoute(lineId, pathId, name, start_time, end_time, status) {
        // Busca a linha e o caminho no banco de dados
        // const line = await Line.findByPk(lineId);
        // const path = await Path.findByPk(pathId);
    
        // // Verifica se a linha e o caminho existem
        // if (!line || !path) {
        //     // Lança um erro para ser tratado no controlador
        //     throw new Error("Line or Path not found");
        // }
    
        // Cria a nova rota
        const newRoute = await Route.create({ lineId, pathId, name, start_time, end_time, status });
        return newRoute;
    }
    

    async getAllRoutes() {
        return await Route.findAll();
    }

    async getRouteByDriver(driverId) {
        return await Route.findOne({
            where: { driver_id: driverId },
            include: [{ model: Path }],
        });
    }
    async getRouteById(id) {
        return await Route.findByPk(id);
    }

    async updateRoute(id, data) {
        const route = await Route.findByPk(id);
        if (route) {
            return await route.update(data);
        }
        throw new Error('Route not found');
    }

    async getAvailableRoutes(lineId) {
        const line = await Line.findByPk(lineId);
        if (!line) {
          throw new Error('Linha não encontrada');
        }
      
        // Obtém as rotas disponíveis para a linha com status = 1
        const routes = await Route.findAll({
          where: { 
            lineId: lineId, // Filtra pelo ID da linha
            status: 0       // Apenas rotas inativas
          },
          attributes: ['id', 'schedule', 'start_time', 'end_time', 'status'], // Dados que você deseja retornar
        });
      
        return routes;
    }

    async deleteRoute(id) {
        const route = await Route.findByPk(id);
        if (route) {
            return await route.destroy();
        }
        throw new Error('Route not found');
    }
}

module.exports = RouteService;