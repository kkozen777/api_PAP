require('dotenv').config(); 

// services/pathService.js
const Path = require('../models/paths');

class PathService {
    async createPath(data) {
        return await Path.create(data);
    }

    async getAllPaths() {
        return await Path.findAll();
    }

    async getPathById(id) {
        return await Path.findByPk(id);
    }

    async updatePath(id, data) {
        const path = await Path.findByPk(id);
        if (path) {
            return await path.update(data);
        }
        throw new Error('Path not found');
    }

    async deletePath(id) {
        const path = await Path.findByPk(id);
        if (path) {
            return await path.destroy();
        }
        throw new Error('Path not found');
    }
}

module.exports = PathService;
