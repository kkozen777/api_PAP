require('dotenv').config(); 

const User = require('../models/users');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

class UserService {
    // Create a new user
    async createUser(email, password, name) {
        try {
            const existingUser = await User.findOne({ where: { email } });
            if (existingUser) {
                return null; // user já existe
            }

            // Hash da senha
            const hashedPassword = await bcrypt.hash(password, 10);

            const newUser = await User.create({ email, password: hashedPassword, name });
            return newUser;
        } catch (error) {
            console.error('Error creating user:', error.message);
            throw error;
        }
    }
        // Authenticate a user
    async authenticateUser(email, password) {
        try {
            const user = await User.findOne({ where: { email } });
            if (!user) {
                return null; // user não encontrado
            }

            // Verificar a senha
            const isPasswordValid = await bcrypt.compare(password, user.password);
            if (!isPasswordValid) {
                return null; // Senha inválida
            }

            // Gerar um token JWT
            const token = jwt.sign({ id: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '1h' });
            return { token, user };
        } catch (error) {
            console.error('Error authenticating user:', error.message);
            throw error;
        }
    }
    // Fetch all users
    async getAllUsers() {
        try {
            const users = await User.findAll();
            return users;
        } catch (error) {
            console.error('Error fetching users:', error.message);
            throw error;
        }
    }

    // Fetch a single user by ID
    async getUserById(userId) {
        try {
            const user = await User.findByPk(userId);
            if (!user) {
                throw new Error('User not found');
            }
            return user;
        } catch (error) {
            console.error('Error fetching user by ID:', error.message);
            throw error;
        }
    }
    async updateUser(id, data) {
        try {
            // Certifique-se de que o usuário existe
            const user = await User.findByPk(id);
    
            if (!user) {
                return null;
            }
    
            // Verifica se o campo "password" está presente nos dados
            if (data.password) {
                // Criptografa o password
                data.password = await bcrypt.hash(data.password, 10);
            }
            return await user.update(data);
        } catch (error) {
            console.error('Error updating user:', error.message);
            throw error;
        }
    }

    async deleteUser(id) {
        try {
            const user = await User.findByPk(id);
            if (!user) {
                return null;
            }
            await user.destroy();
            return { message: 'user deleted successfully.' };
        } catch (error) {
            console.error('Error deleting user:', error.message);
            throw error;
        }
    }
    
}

module.exports = UserService;