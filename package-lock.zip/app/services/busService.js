const Bus = require('../models/buses');
const Driver = require('../models/drivers');

class busService {
    // Create a new Bus
    async createBus(routeId, driverId, licensePlate, currentLatitude, currentLongitude, status) {
        try {
            const existingBus = await Bus.findOne({ where: { licensePlate } });
            if(existingBus){
                return null;
            }
            const newBus = await Bus.create({routeId, driverId, licensePlate, currentLatitude, currentLongitude, status});
            return newBus;
        } catch (error) {
            console.error('Error creating Bus:', error.message);
            throw error;
        }
    }
    async updateBus(id,updates) {
        try {
            // Ensure bus exists
            const bus = await Bus.findOne({ where: { id } });

            if (!bus) {
                return null;
            }

            // Update bus fields
            Object.keys(updates).forEach((key) => {
                if (bus[key] !== updates[key]) {
                    bus[key] = updates[key];
                }
            });

            // Save changes to database
            await bus.save();
            return bus;
        } catch (error) {
            console.error('Error deleting user:', error.message);
            throw error;
        }
    }
    // Fetch all buses
    async getAllBuses() {
        try {
            const buses = await Bus.findAll();
            return buses;
        } catch (error) {
            console.error('Error fetching buses:', error.message);
            throw error;
        }
    }

    // Fetch a single bus by ID
    async getBusById(id) {
        try {
            const bus = await Bus.findByPk(id);
            if (!bus) {
                throw new Error('Bus not found');
            }
            return bus;
        } catch (error) {
            console.error('Error fetching bus by ID:', error.message);
            throw error;
        }
    }

    // Fetch a single bus by ID
    async getBusDriver(id) {
        try {

            const bus = await Bus.findByPk(id);
            if (!bus) {
                throw new Error('Bus not found');
            }

            const driver = await Driver.findByPk(bus.driverId);
            if (!driver) {
                throw new Error('Driver not found for this bus');
            }

            return driver;
        } catch (error) {
            console.error('Error fetching driver by bus ID:', error.message);
            throw error;
        }
    }

    async addRoute(busId, routeId) {
        try {
            // Verifica se o ônibus existe
            const bus = await Bus.findByPk(busId);
            if (!bus) {
                throw new Error('Bus not found');
            }

            // Verifica se o motorista existe
            const driver = await Route.findByPk(routeId);
            if (!driver) {
                throw new Error('Driver not found');
            }

            // Atualiza o campo driverId do ônibus
            bus.routeId = routeId;
            await bus.save(); // Salva a alteração no banco

            return bus; // Retorna o ônibus atualizado
        } catch (error) {
            console.error('Error binding bus and driver:', error.message);
            throw error;
        }
    }

    async bindBusAndDriver(busId, driverId) {
        try {
            // Verifica se o ônibus existe
            const bus = await Bus.findByPk(busId);
            if (!bus) {
                throw new Error('Bus not found');
            }

            // Verifica se o motorista existe
            const driver = await Driver.findByPk(driverId);
            if (!driver) {
                throw new Error('Driver not found');
            }

            // Atualiza o campo driverId do ônibus
            bus.driverId = driverId;
            await bus.save(); // Salva a alteração no banco

            return bus; // Retorna o ônibus atualizado
        } catch (error) {
            console.error('Error binding bus and driver:', error.message);
            throw error;
        }
    }

    async unbindBusAndDriver(id) {
        try {
            const bus = await Bus.findByPk(id);
            if (!bus) {
                return null;
            }
            bus.driverId = null;
            await bus.save();
            return bus;
        } catch (error) {
            console.error('Error binding bus and driver:', error.message);
            throw error;
        }
    }

    async deleteBus(id) {
        try {
            const bus = await Bus.findByPk(id);
            if (!bus) {
                return null;
            }
            await bus.destroy();
            return { message: 'Bus deleted successfully.' };
        } catch (error) {
            console.error('Error deleting bus:', error.message);
            throw error;
        }
    }

    // return all the buses saying if their on off etc
    async getBusesStatus() {
        try {
            const buses = await Bus.findAll({
                attributes: ['id', 'driverId', 'routeId', 'status'], // Apenas os campos necessários
            });
            const statusBuses = {
                stopped: buses.filter(bus => bus.status === 0).map(bus => ({
                    id: bus.id,
                    driverId: bus.driverId,
                    routeId: bus.routeId,
                    status: bus.status

                })),
                runningButStopped: buses.filter(bus => bus.status === 1).map(bus => ({
                    id: bus.id,
                    driverId: bus.driverId,
                    routeId: bus.routeId,
                    status: bus.status
                })),
                runningAndMoving: buses.filter(bus => bus.status === 2).map(bus => ({
                    id: bus.id,
                    driverId: bus.driverId,
                    routeId: bus.routeId,
                    status: bus.status
                }))
            };
            return statusBuses;
        } catch (errostatusBusesr) {
            console.error('Error fetching bus by ID:', error.message);
            throw error;
        }
    }
};

module.exports = busService;