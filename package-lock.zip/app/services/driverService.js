const Driver = require('../models/drivers');

const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

class DriverService {
    // Create a new Driver
    async createDriver(driverNumber, password, name) {
        try {
            const existingDriver = await Driver.findOne({ where: { driverNumber } });
            if(existingDriver){
                return null;
            }

            const hashedPassword = await bcrypt.hash(password, 10);

            const newDriver = await Driver.create({ driverNumber, password: hashedPassword, name });
            return newDriver;
        } catch (error) {
            console.error('Error creating Driver:', error.message);
            throw error;
        }
    }
    
    async authenticateDriver(driverNumber, password) {
        try {
            const driver = await Driver.findOne({ where: { driverNumber } });
            if (!driver) {
                return null; // driver não encontrado
            }

            // Verificar a senha
            const isPasswordValid = await bcrypt.compare(password, driver.password);
            if (!isPasswordValid) {
                return null; // Senha inválida
            }

            // Gerar um token JWT
            const token = jwt.sign({ id: driver.id, driverNumber: driver.driverNumber }, process.env.JWT_SECRET, { expiresIn: '1h' });
            return { token, driver };
        } catch (error) {
            console.error('Error authenticating driver:', error.message);
            throw error;
        }
    }

    // Fetch all Driver
    async getAllDrivers() {
        try {
            const drivers = await Driver.findAll();
            return drivers;
        } catch (error) {
            console.error('Error fetching drivers:', error.message);
            throw error;
        }
    }

    // Fetch a single Driver by ID
    async getDriverById(driverId) {
        try {
            const Driver = await Driver.findByPk(driverId);
            if (!driver) {
                throw new Error('Driver not found');
            }
            return Driver;
        } catch (error) {
            console.error('Error fetching Driver by ID:', error.message);
            throw error;
        }
    }
    async updateDriver(id,data) {
        try {
            // Certifique-se de que o usuário existe
            const driver = await Driver.findByPk(id);
    
            if (!driver) {
                return null;
            }
    
            // Verifica se o campo "password" está presente nos dados
            if (data.password) {
                // Criptografa o password
                data.password = await bcrypt.hash(data.password, 10);
            }
            return await driver.update(data);
        } catch (error) {
            console.error('Error updating driver:', error.message);
            throw error;
        }
    }
    async deleteDriver(id) {
        try {
            const driver = await Driver.findByPk(id);
            if (!driver) {
                return null;
            }
            await driver.destroy();
            return { message: 'driver deleted successfully.' };
        } catch (error) {
            console.error('Error deleting driver:', error.message);
            throw error;
        }
    }
}

module.exports = DriverService;