const { DataTypes } = require('sequelize');
const sequelize = require('../config/database/db'); // Sequelize instance

const Bus = sequelize.define('Buses', {
    routeId: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    driverId: {
        type: DataTypes.INTEGER,
        allowNull: true,
        // references: {
        //     model: 'Drivers',
        //     key: 'id',
        // },
    },
    licensePlate: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
    },
    currentLatitude: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    currentLongitude: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    status: {
        type: DataTypes.TINYINT,
        allowNull: true,
    },
}, {
    tableName: 'buses', // Database table name
    timestamps: true,  // Automatically adds createdAt and updatedAt
});

module.exports = Bus;