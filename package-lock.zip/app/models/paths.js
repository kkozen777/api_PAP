// models/Path.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database/db');
// const Route = require('./routesModel'); // Importando o modelo Route

const Path = sequelize.define('Path', {
    name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    coordinates: {
        type: DataTypes.JSON, // Usado para armazenar coordenadas geográficas
        allowNull: true,
    },
}, {
    tableName: 'paths',
    timestamps: true,
});

// Relacionamento: Um path pode ter várias rotas
// Path.hasMany(Route, { foreignKey: 'pathId' });

module.exports = Path;
