// models/RouteStatus.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database/db'); // Instância do Sequelize

const DriverRoute = sequelize.define('DriverRoute', {
    driverId: {
        type: DataTypes.INTEGER, // UUID ou INT para o ID do driver
        allowNull: false,
        // references: {
        //     model: 'drivers', // Assume-se que a tabela 'drivers' existe
        //     key: 'id',
        // },
    },
    routeId: {
        type: DataTypes.INTEGER, // UUID ou INT para o ID da rota
        allowNull: false,
        // references: {
        //     model: 'route', // Assume-se que a tabela 'routes' existe
        //     key: 'id',
        // },
    },
    status: {
        type: DataTypes.TINYINT, // ENUM para status
        allowNull: false,
    },
    started_at: {
        type: DataTypes.DATE, // Data e hora de início
        allowNull: false,
        defaultValue: DataTypes.NOW, // Define a data e hora atual como padrão
    },
    ended_at: {
        type: DataTypes.DATE, // Data e hora de término (pode ser nulo se a rota não tiver sido concluída)
        allowNull: true,
    },
}, {
    tableName: 'driverRoute', // Nome da tabela no banco de dados
    timestamps: true,  // Adiciona createdAt e updatedAt automaticamente
});

module.exports = DriverRoute;
