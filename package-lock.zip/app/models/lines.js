// models/Line.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database/db');
// const Route = require('./routesModel'); // Importando o modelo Route

const Line = sequelize.define('Line', {
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    schedules: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    status: {
        type: DataTypes.TINYINT,
        allowNull: true,
    }
}, {
    tableName: 'lines',
    timestamps: true,
});

// Relacionamento: Uma linha pode ter várias rotas
// Line.hasMany(Route, { foreignKey: 'lineId' });

module.exports = Line;