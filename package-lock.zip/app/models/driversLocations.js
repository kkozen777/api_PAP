// models/DriverLocation.js
const { DataTypes, DATE } = require('sequelize');
const sequelize = require('../config/database/db'); // Instância do Sequelize
// const Driver = require('./drivers');  // Importa o modelo Driver
// const Route = require('./routesModel');  // Importa o modelo Route

const DriverLocation = sequelize.define('DriverLocation', {
    id: {
        type: DataTypes.BIGINT,
        autoIncrement: true,
        primaryKey: true,
      },
      driverId: {
        type: DataTypes.BIGINT,
        allowNull: false,
      },
      latitude: {
        type: DataTypes.DECIMAL(9, 6),
        allowNull: false,
      },
      longitude: {
        type: DataTypes.DECIMAL(9, 6),
        allowNull: false,
      },
      timestamp: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW, // Define a data e hora atual como padrão
      },
    }, {
      tableName: 'driversLocations',
      timestamps: false,
      indexes: [
        {
          unique: true,
          fields: ['driverId', 'timestamp'], // Cria a restrição UNIQUE
          name: 'unique_driver_timestamp', // Nome opcional para o índice
        },
      ],
    });
// DriverLocation.belongsTo(Driver, {
//     foreignKey: 'driverId', // Chave estrangeira no modelo DriverLocation
//     targetKey: 'id', // Chave primária no modelo Driver
// });

// 2. DriverLocation pertence a uma Route
// DriverLocation.belongsTo(Route, {
//     foreignKey: 'routeId', // Chave estrangeira no modelo DriverLocation
//     targetKey: 'id', // Chave primária no modelo Route
// });
module.exports = DriverLocation;
