// routes/pathRoutes.js
const express = require('express');
const router = express.Router();
const PathService = require('../services/pathService');
const pathService = new PathService();

// Rota para criar um novo Path
router.post('/', async (req, res) => {
    try {
        const path = await pathService.createPath(req.body);
        res.status(201).json(path);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Rota para listar todos os Paths
router.get('/', async (req, res) => {
    try {
        const paths = await pathService.getAllPaths();
        res.status(200).json(paths);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Rota para buscar um Path pelo ID
router.get('/:id', async (req, res) => {
    try {
        const path = await pathService.getPathById(req.params.id);
        if (path) {
            res.status(200).json(path);
        } else {
            res.status(404).json({ message: 'Path not found' });
        }
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

router.delete('/deletePath/:id', async (req, res) => {
    try {
        const path = await pathService.deletePath(req.params.id);
        if (path) {
            res.status(200).json(path);
        } else {
            res.status(404).json({ message: 'Path not found' });
        }
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
