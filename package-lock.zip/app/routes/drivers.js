const validate = require('../middlewares/validation'); // Import the middleware
const { createDriverSchema } = require('../middlewares/schemas/drivers');
const { updateDriverSchema } = require('../middlewares/schemas/drivers');

const DriverService = require('../services/driverService');

// Instantiate the service
const driverService = new DriverService();
const express = require('express');
const router = express.Router();

// GET /drivers
router.get('/', async (req, res) => {
    const drivers = await driverService.getAllDrivers();
    res.status(201).json({ message: 'Here are all the drivers', drivers });
});

// POST /drivers 
router.post('/', validate(createDriverSchema), async (req, res) => {
    const { driverNumber, password, name } = req.body;
    try {
        const Driver = await driverService.createDriver(driverNumber, password, name);
        if(!Driver){
            return res.status(404).json({ error: 'Driver already exists' });
        }
        res.status(201).json({ message: 'Driver created successfully', driver: Driver });
    } catch (error) {
        res.status(500).json({ error: 'Error creating Driver', details: error.message });
    }
});

router.post('/login', async (req, res) => {
    const { driverNumber, password, name } = req.body;

    try {
        const authResponse = await driverService.authenticateDriver(driverNumber, password, name);
        if (!authResponse) {
            return res.status(401).json({ message: 'Credenciais inválidas!' });
        }

        res.json({ message: 'Login bem-sucedido!', token: authResponse.token, driver: authResponse.driver });
    } catch (error) {
        res.status(500).json({ message: 'Erro ao logar user.' });
    }
});

// PATCH /drivers/updateDriver/:id
router.patch('/updateDriver/:id', validate(updateDriverSchema), async (req, res) => {
    try {
        const { id } = req.params; // Get driver ID from URL
        const updates = req.body; // Get update data from request body
        const updatedDriver = await driverService.updateDriver(id,updates);

        if (updatedDriver == null) {
            return res.status(404).json({ error: 'driver does not exist.' });
        }
        // Return success response
        res.status(200).json({ message: 'Driver updated successfully', updatedDriver });
    } catch (error) {
        // Handle errors
        if (error.name === 'SequelizeUniqueConstraintError') {
            return res.status(400).json({ message: 'driverNumber is already in use' });
        }
        res.status(500).json({ error: 'Error updating driver', details: error.message });
    }
});

// DELETE /drivers/deleteDriver/:id
router.delete('/deleteDriver/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const result = await driverService.deleteDriver(id);

        if (result == null) {
            return res.status(404).json({ error: 'driver does not exist.' });
        }

        return res.status(200).json(result);
    } catch (error) {
        console.error('Error deleting driver:', error.message);
        return res.status(500).json({ error: 'Error deleting driver.', details: error.message });
    }
});



module.exports = router;