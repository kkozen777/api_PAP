const validate = require('../middlewares/validation.js'); // Import the middleware
const { createUserSchema } = require('../middlewares/schemas/users.js');
const { updateUserSchema } = require('../middlewares/schemas/users.js');

const UserService = require('../services/userService.js');
// const User = require('../models/users.js');
const userService = new UserService();
const express = require('express');
const router = express.Router();

// GET /users
router.get('/', async (req, res) => {
    const users = await userService.getAllUsers();
    res.status(201).json({ message: 'Tao aqui todos os users', users});
});

// POST /users
router.post('/signup', validate(createUserSchema), async (req, res) => {
    const { email, password, name } = req.body;
    try {
        const newUser = await userService.createUser(email, password, name);
        if(!newUser){
            return res.status(404).json({ error: 'User already exists' });
        }
        res.status(201).json({ message: 'User created successfully', user: newUser });
    } catch (error) {
        res.status(500).json({ error: 'Error creating user', details: error.message });
    }
});

router.post('/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        const authResponse = await userService.authenticateUser(email, password);
        if (!authResponse) {
            return res.status(401).json({ message: 'Credenciais inválidas!' });
        }

        res.json({ message: 'Login bem-sucedido!', token: authResponse.token, user: authResponse.user });
    } catch (error) {
        res.status(500).json({ message: 'Erro ao logar user.' });
    }
});

router.patch('/updateUser/:id', validate(updateUserSchema), async (req, res) => {
    try {
        const { id } = req.params; // Get User ID from URL
        const updates = req.body; // Get update data from request body
        const updatedUser = await userService.updateUser(id,updates);

        if (updatedUser == null) {
            return res.status(404).json({ error: 'User does not exist.' });
        }
        // Return success response
        res.status(200).json({ message: 'User updated successfully', updatedUser });
    } catch (error) {
        // Handle errors
        if (error.name === 'SequelizeUniqueConstraintError') {
            return res.status(400).json({ message: 'email is already in use' });
        }
        res.status(500).json({ error: 'Error updating User', details: error.message });
    }
});

router.delete('/deleteUser/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const result = await userService.deleteUser(id);

        if (result == null) {
            return res.status(404).json({ error: 'user does not exist.' });
        }

        return res.status(200).json(result);
    } catch (error) {
        console.error('Error deleting user:', error.message);
        return res.status(500).json({ error: 'Error deleting user.', details: error.message });
    }
});

module.exports = router;