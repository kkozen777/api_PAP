const validate = require('../middlewares/validation'); // Import the middleware
const { createRouteSchema } = require('../middlewares/schemas/routesSchema');
const { updateRouteSchema } = require('../middlewares/schemas/routesSchema');

const RouteService = require('../services/routeService');

// Instantiate the service
const routeService = new RouteService();
const express = require('express');
const router = express.Router();

// GET /routes
router.get('/', async (req, res) => {
    const routes = await routeService.getAllRoutes();
    res.status(201).json({ message: 'Here are all the routes', routes });
});

router.get('/availableRoutes/:lineId', async (req, res) => {
    const { lineId } = req.params;
    
    try {
      // Obtém as rotas disponíveis com base no ID da linha
      const availableRoutes = await routeService.getAvailableRoutes(lineId);
      
      if (availableRoutes.length === 0) {
        return res.status(404).json({
          success: false,
          message: 'Nenhuma rota disponível para a linha especificada',
        });
      }
      
      return res.status(200).json({
        success: true,
        data: availableRoutes,
      });
    } catch (error) {
      console.error('Erro no request:', error);
      return res.status(500).json({
        success: false,
        message: 'Erro ao mostrar as rotas disponíveis',
      });
    }
});
  

router.get('/driver/:driverId', async (req, res) => {
    try {
        const { driverId } = req.params;
        const route = await routeService.getRouteByDriver(driverId);
        if (route) {
            res.status(200).json(route);
        } else {
            res.status(404).json({ message: 'Route not found for this driver' });
        }
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});



// GET bus by id
router.get('/getRoute/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const getRoute = await routeService.getRouteById(id)
        res.status(201).json({ message: 'Here is the Route:', route: getRoute });
    } catch (error) {
        res.status(500).json({ error: 'Error getting Route', details: error.message });
    }
});

router.post('/', validate(createRouteSchema), async (req, res) => { 
    const { lineId, pathId, name, start_time, end_time, status } = req.body;

    try {
        const newRoute = await routeService.createRoute(lineId, pathId, name, start_time, end_time, status);
        res.status(201).json({ message: 'Route created successfully', route: newRoute });
    } catch (error) {
        // Captura o erro lançado pelo serviço
        console.error('Error creating Route:', error);
        res.status(400).json({ error: 'Error creating Route', details: error.message });
    }
});

// PATCH /routes/updateRoute/:id
router.patch('/updateRoute/:id', validate(updateRouteSchema), async (req, res) => {
    try {
        const { id } = req.params; // Get route ID from URL
        const updates = req.body; // Get update data from request body
        const updatedRoute = await routeService.updateRoute(id, updates);

        if (updatedRoute == null) {
            return res.status(404).json({ error: 'Route does not exist.' });
        }
        // Return success response
        res.status(200).json({ message: 'Route updated successfully', updatedRoute });
    } catch (error) {
        // Handle errors
        if (error.name === 'SequelizeUniqueConstraintError') {
            return res.status(400).json({ message: 'routeNumber is already in use' });
        }
        res.status(500).json({ error: 'Error updating route', details: error.message });
    }
});

router.delete('/deleteRoute/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const result = await routeService.deleteRoute(id);

        if (result == null) {
            return res.status(404).json({ error: 'route does not exist.' });
        }

        return res.status(200).json(result);
    } catch (error) {
        console.error('Error deleting user:', error.message);
        return res.status(500).json({ error: 'Error deleting user.', details: error.message });
    }
});

module.exports = router;