const validate = require('../middlewares/validation'); // Import the middleware
const { createBusSchema } = require('../middlewares/schemas/buses');
const { updateBusSchema } = require('../middlewares/schemas/buses');

const BusService = require('../services/busService');

// Instantiate the service
const busService = new BusService();
const express = require('express');
const router = express.Router();

// GET /buses
router.get('/', async (req, res) => {
    const buses = await busService.getAllBuses();
    res.status(201).json({ message: 'Here are all the buses', buses });
});

// GET bus by id
router.get('/getBus/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const getBus = await busService.getBusById(id)
        res.status(201).json({ message: 'Here is the bus:', bus: getBus });
    } catch (error) {
        res.status(500).json({ error: 'Error getting bus', details: error.message });
    }
});

// GET bus driver by id
router.get('/getBusDriver/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const getBus = await busService.getBusDriver(id)
        return res.status(201).json({ message: 'Here is the bus driver:', bus: getBus });
    } catch (error) {
        console.error('Error fetching driver by bus ID:', error.message);

        if (error.message === 'Bus not found') {
            return res.status(404).json({ message: 'Bus not found' });
        }
        
        if (error.message === 'Driver not found for this bus') {
            return res.status(404).json({ message: 'Driver not found for this bus' });
        }
        return res.status(500).json({ message: 'Internal server error', error: error.message });
    }
});
// Gives a json with the bus status (stop, on, off, riding...)
router.get('/getBusesStatus', async (req, res) => {
    try{
        const buses = await busService.getBusesStatus();
        res.status(201).json({ message: 'Here are all the buses', buses });

    }catch (error) {
        console.error('Error fetching buses status:', error.message);
        res.status(500).json({ error: 'Error fetching buses status', details: error.message });
    }
});
// Create bus
router.post('/', validate(createBusSchema), async (req, res) => {
    const { routeId, driverId, licensePlate, currentLatitude, currentLongitude, status } = req.body;

    try {
        const newBus = await busService.createBus(routeId, driverId, licensePlate, currentLatitude, currentLongitude, status);
        if(!newBus){
            return res.status(404).json({ error: 'bus already exists' });
        }
        res.status(201).json({ message: 'bus created successfully', bus: newBus });
    } catch (error) {
        res.status(500).json({ error: 'Error creating bus', details: error.message });
    }

});

// add the route that the bus need
router.post('/addRoute', async (req, res) => {
    try {
        const { id, idRoute } = req.params;

        const busId = id;
        const routeId = idRoute

        const result = await busService.bindBusAndDriver(busId, routeId);

        return res.status(200).json({ message: 'Bus and driver successfully binded.', data: result });
    } catch (error) {
        res.status(500).json({ error: 'Error adding the route: ', details: error.message });
    }});

// Bind a bus with the driverId
router.post('/bindbusAndDriver/:id/:driverId', async (req, res) => {
    try {
        const { id, driverId } = req.params;

        const busId = id;
        const idDriver = driverId;

        const result = await busService.bindBusAndDriver(busId, idDriver);

        return res.status(200).json({ message: 'Bus and driver successfully binded.', data: result });
    } catch (error) {
        res.status(500).json({ error: 'Error bindind bus driver', details: error.message });
    }
});

// Unbind the driver to the bus, it removes the driverId
router.post('/unbindBusAndDriver/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const busId = id;

        const result = await busService.unbindBusAndDriver(busId);

        if(!result){
            return res.status(404).json({ error: 'bus does not exist' });
        }
        return res.status(200).json({ message: 'Bus and driver successfully unbinded.', data: result });
    } catch (error) {
        res.status(500).json({ error: 'Error unbinding bus driver', details: error.message });
    }
});

// Change the bus values
router.patch('/updatebus/:id', async (req, res) => {
    try {
        const { id } = req.params; // Get driver ID from URL
        const updates = req.body; // Get update data from request body
        const updatedBus = await busService.updateBus(id,updates);

        if (updatedBus == null) {
            return res.status(404).json({ error: 'driver does not exist.' });
        }
        // Return success response
        res.status(200).json({ message: 'Driver updated successfully', updatedBus });
    } catch (error) {
        // Handle errors
        if (error.name === 'SequelizeUniqueConstraintError') {
            return res.status(400).json({ message: 'driverNumber is already in use' });
        }
        res.status(500).json({ error: 'Error updating driver', details: error.message });
    }
});

// Deletes a bus
router.delete('/deletebus/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const result = await busService.deleteBus(id);

        if (result == null) {
            return res.status(404).json({ error: 'Bus does not exist.' });
        }

        return res.status(200).json(result);
    } catch (error) {
        console.error('Error deleting bus:', error.message);
        return res.status(500).json({ error: 'Error deleting bus.', details: error.message });
    }
});



module.exports = router;