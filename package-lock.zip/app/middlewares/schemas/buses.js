const Joi = require('joi');
// validation vai validar o vue futuramente
// validar todos os dados que entram e saiem


// Schema for creating a user
// ex: email: Joi.string()(tipo de dados) .email(oque tem de ser().required()   
const createBusSchema = Joi.object({
    routeId: Joi.number().optional(), // Must be a valid email
    driverId: Joi.number().optional(), // Minimum 6 characters
    licensePlate: Joi.string().required(), // Optional name field
    currentLatitude: Joi.string().optional(), // Optional name field
    currentLongitude: Joi.string().optional(), // Optional name field
    status: Joi.number().integer().min(0).max(2).optional(), // Optional name field
});

const updateBusSchema = Joi.object({
    routeId: Joi.number().optional(), // Must be a valid email
    driverId: Joi.number().optional(), // Minimum 6 characters
    licensePlate: Joi.string().optional(), // Optional name field
    currentLatitude: Joi.string().optional(), // Optional name field
    currentLongitude: Joi.string().optional(), // Optional name field
    status: Joi.number().integer().min(0).max(2).optional(), // Optional name field
});

module.exports = { createBusSchema, updateBusSchema };
