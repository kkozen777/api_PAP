const Joi = require('joi');

const createRouteSchema = Joi.object({
    lineId: Joi.number().integer().required(), // Optional name field
    pathId: Joi.number().integer().required(), // Optional name field
    schedule: Joi.string().required(), 
    start_time: Joi.string().required(), 
    end_time: Joi.string().required(), // Minimum 6 characters
    status: Joi.number().integer().min(0).max(2).required(), // Optional name field
});

const updateRouteSchema = Joi.object({
    name: Joi.string(), 
    line: Joi.string().optional(), // Minimum 6 characters
    schedules: Joi.string().optional(), // Optional name field
    status: Joi.number().integer().min(0).max(2).optional(), // Optional name field
});

module.exports = { createRouteSchema, updateRouteSchema };