const Joi = require('joi');
// validation vai validar o vue futuramente
// validar todos os dados que entram e saiem


// Schema for creating a user
// ex: email: Joi.string()(tipo de dados) .email(oque tem de ser().required()   
const createDriverSchema = Joi.object({
    driverNumber: Joi.string().required(), 
    password: Joi.string().min(6).required(), // Minimum 6 characters
    name: Joi.string().required(), // Optional name field
});

const updateDriverSchema = Joi.object({
    driverNumber: Joi.string().optional(), // Must be a valid email
    password: Joi.string().min(6).optional(), // Minimum 6 characters
    name: Joi.string().optional(), // Optional name field
});



module.exports = { createDriverSchema, updateDriverSchema };