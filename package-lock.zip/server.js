const express = require('express');
const app = express();
const port = 3000;

const cors = require('cors');

// const http = require('http');
// const { Server } = require('socket.io');
// const http = require('http');
// const { Server } = require('socket.io');

// // Evento de WebSocket para localização em tempo real
// io.on('connection', (socket) => {
//     console.log('Usuário conectado:', socket.id);
  
//     // Ouve eventos de localização do motorista
//     socket.on('location-update', (data) => {
//       console.log('Localização recebida:', data);
  
//       // Envia a localização para todos os clientes conectados
//       io.emit('location-update', data);
//     });
  
//     socket.on('disconnect', () => {
//       console.log('Usuário desconectado:', socket.id);
//     });
//   });
  
// Habilita o CORS para todas as origens (se você quiser restringir a origens específicas, pode modificar isso)
app.use(cors());

// Middleware to parse JSON
app.use(express.json());

// Import routes
//const trucksRoute = require('./routes/trucks');
const usersRoute = require('./app/routes/users');
const driversRoute = require('./app/routes/drivers');
const driversRouteRoute = require('./app/routes/driverRoutes');
const driverLocationsRoute = require('./app/routes/driverLocations');
const busesRoute = require('./app/routes/buses');
const routesRoute = require('./app/routes/routesRoute');
const linesRoute = require('./app/routes/lines');
const pathsRoute = require('./app/routes/paths');
const sequelize = require('./app/config/database/db');

const initDatabase = async () => {
    try {
        await sequelize.authenticate();
        console.log('Database connection established successfully.');

        // Synchronize models with the database
        await sequelize.sync({ force: false }); // Set to true to drop and recreate tables
        console.log('Models synchronized successfully.');
    } catch (error) {
        console.error('Unable to connect to the database:', error.message);
        process.exit(1); // Exit the process if the database connection fails
    }
};


// Routes
app.use('/users', usersRoute);
app.use('/drivers', driversRoute);
app.use('/driverRoute', driversRouteRoute);
app.use('/driversLocations', driverLocationsRoute);
app.use('/buses', busesRoute);
app.use('/routes', routesRoute);
app.use('/lines', linesRoute);
app.use('/paths', pathsRoute);



// Start the server
app.listen(port, async () => {
    console.log(`Server running at http://localhost:${port}`);
    await initDatabase();
});

